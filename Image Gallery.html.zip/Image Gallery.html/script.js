const images = [
  'download12.jpg',
  'download6.jpg',
  'download5.jpg',
  'download4.jpg'
];

let currentIndex = 0;

const currentImage = document.getElementById('current-image');
const thumbnails = document.querySelectorAll('.thumbnails img');

function showImage(index) {
  currentImage.src = images[index];
  thumbnails.forEach((thumbnail, i) => {
    thumbnail.classList.toggle('active', i === index);
  });
}

function nextImage() {
  currentIndex = (currentIndex + 1) % images.length;
  showImage(currentIndex);
}

function prevImage() {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  showImage(currentIndex);
}

function selectImage(index) {
  currentIndex = index;
  showImage(index);
}

// Add event listeners
document.getElementById('next-btn').addEventListener('click', nextImage);
document.getElementById('prev-btn').addEventListener('click', prevImage);

// Initialize gallery
showImage(currentIndex);
